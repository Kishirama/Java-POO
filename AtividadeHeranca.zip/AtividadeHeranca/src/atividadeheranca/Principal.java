/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividadeheranca;

/**
 *
 * @author IFTM
 */
public class Principal {
    public static void main(String[] args) {
        // Testing ContaBancaria
        System.out.println("=== Contas Bancarias ===");
        ContaBancaria conta1 = new ContaBancaria("Joao Silva", 2000.0, 3000.0);
        ContaBancaria conta2 = new ContaBancaria("", 500.0, 2000.0); 
        ContaBancaria conta3 = new ContaBancaria("Maria Santos", 2000.0, 2500.0);
        
        System.out.println("\nConta 1:");
        conta1.verificarSaldo();
        conta1.depositar(500.0);
        conta1.sacar(200.0);
        conta1.sacar(2000.0); 
        
        System.out.println("\nConta 2 (nome vazio):");
        conta2.verificarSaldo(); 
        
        System.out.println("\nConta 3:");
        conta3.verificarSaldo();
        
        // Testing ContaPoupanca
        System.out.println("\n=== Contas Poupanca ===");
        ContaPoupanca poupanca1 = new ContaPoupanca("Carlos Oliveira", 2000.0, 4000.0, 1.5);
        ContaPoupanca poupanca2 = new ContaPoupanca("Ana Pereira", 3000.0, 5000.0, 2.0);
        ContaPoupanca poupanca3 = new ContaPoupanca("Pedro Costa", 4000.0, 6000.0, 3.0);
        
        System.out.println("\nPoupanca 1:");
        poupanca1.verificarSaldo();
        poupanca1.aplicarJuros();
        
        System.out.println("\nPoupanca 2:");
        poupanca2.verificarSaldo();
        poupanca2.aplicarJuros();
        
        System.out.println("\nPoupanca 3 (taxa invalida):");
        poupanca3.verificarSaldo();
        System.out.println("Taxa de juros: " + poupanca3.getTaxaJuros());
        poupanca3.aplicarJuros();
        

    }
}
